package service

import (
	"dragon-islet/internal/global"
	"dragon-islet/internal/logic"
	"dragon-islet/internal/model"
	"dragon-islet/pkg/apimart"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"math/rand"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
)

type DragonService struct{}

// StartLifeCycle 启动龙嗣生命周期管理 (动态消耗)
func (s *DragonService) StartLifeCycle() {
	ticker := time.NewTicker(1 * time.Hour)
	go func() {
		for range ticker.C {
			// 1. 处理饱食度消耗 (Common: 5, Rare: 8, Epic: 12)
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND hunger > 0", "common").
				Update("hunger", global.DB.Raw("CASE WHEN hunger >= 5 THEN hunger - 5 ELSE 0 END"))
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND hunger > 0", "rare").
				Update("hunger", global.DB.Raw("CASE WHEN hunger >= 8 THEN hunger - 8 ELSE 0 END"))
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND hunger > 0", "epic").
				Update("hunger", global.DB.Raw("CASE WHEN hunger >= 12 THEN hunger - 12 ELSE 0 END"))
			
			// 2. 处理心情值消耗 (Common: 3, Rare: 5, Epic: 8)
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND happiness > 0", "common").
				Update("happiness", global.DB.Raw("CASE WHEN happiness >= 3 THEN happiness - 3 ELSE 0 END"))
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND happiness > 0", "rare").
				Update("happiness", global.DB.Raw("CASE WHEN happiness >= 5 THEN happiness - 5 ELSE 0 END"))
			global.DB.Model(&model.Dragon{}).Where("rarity = ? AND happiness > 0", "epic").
				Update("happiness", global.DB.Raw("CASE WHEN happiness >= 8 THEN happiness - 8 ELSE 0 END"))
		}
	}()
}

// GetDragon 获取用户的龙
func (s *DragonService) GetDragon(userID uint) (*model.Dragon, error) {
	var dragon model.Dragon
	err := global.DB.Where("user_id = ? AND is_gone = ?", userID, false).First(&dragon).Error
	if err != nil {
		return nil, err
	}
	// 打开界面自动签到
	s.UpdateTaskProgress(userID, "sign_in", 1)
	return &dragon, nil
}

// GetItems 获取用户的物品
func (s *DragonService) GetItems(userID uint) ([]model.UserItem, error) {
	var items []model.UserItem
	err := global.DB.Where("user_id = ?", userID).Find(&items).Error
	return items, err
}

// UseItem 使用道具
func (s *DragonService) UseItem(userID uint, itemType string) (string, error) {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return "", errors.New("你还没有领养龙嗣")
	}

	var item model.UserItem
	if err := global.DB.Where("user_id = ? AND type = ?", userID, itemType).First(&item).Error; err != nil || item.Count <= 0 {
		return "", errors.New("你囊中并无此物")
	}

	msg := ""
	switch itemType {
	case "exp_pill":
		dragon.Exp += 50
		msg = "龙宝宝吞下了龙髓丹，周身灵力激荡，成长值显著提升！"
	case "sacrifice_stone":
		if dragon.Hunger < 30 {
			return "", errors.New("龙宝宝现在太虚弱了，无法承受献祭之石的力量")
		}
		dragon.Hunger -= 30
		dragon.Exp += 100
		msg = "献祭之石发出了幽暗的光芒，虽然饱食度骤降，但龙宝宝的力量得到了质的飞跃！"
	default:
		return "", errors.New("此物尚不知如何使用")
	}

	// 消耗道具
	item.Count--
	global.DB.Save(&item)
	global.DB.Save(dragon)

	return msg, nil
}

// ReleaseDragon 放生龙 (需要密码校验)
func (s *DragonService) ReleaseDragon(userID uint, password string) error {
	// 1. 获取用户
	var user model.User
	if err := global.DB.First(&user, userID).Error; err != nil {
		return errors.New("游侠身份验证失败")
	}

	// 2. 验证密码
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return errors.New("密语校验失败，无法解除契约")
	}

	// 3. 获取龙
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return errors.New("你并无契约龙嗣可以放生")
	}

	// 4. 更新状态
	dragon.IsGone = true
	if err := global.DB.Save(dragon).Error; err != nil {
		return err
	}

	// 5. 自动在广场播报
	releaseMsg := fmt.Sprintf("✨ 游侠 **%s** 解除了与龙嗣 **%s** 的契约。只见那龙化作一道霞光，隐入云端深处，回归了自然的怀抱...", user.Username, dragon.Name)
	msg := &model.Message{
		Content:   releaseMsg,
		IsAIReply: true, // 标记为 AI/系统 消息样式
	}
	global.DB.Create(msg)
	logic.GlobalHub.BroadcastMessage(msg)

	return nil
}

// TriggerRandomEvent 触发随机事件 (AI 故事 + 道具/属性奖励)
func (s *DragonService) TriggerRandomEvent(userID uint, actionType string) (string, error) {
	dragon, _ := s.GetDragon(userID)
	if dragon == nil { return "", nil }

	// 1. 确定奖励池
	rewardPool := []struct {
		Type  string // 'item', 'stat'
		Value string // 'exp_pill', 'sacrifice_stone', 'exp', 'happiness'
		Amt   int
		Name  string
	}{
		{Type: "stat", Value: "exp", Amt: 50, Name: "额外成长值"},
		{Type: "item", Value: "exp_pill", Amt: 1, Name: "龙髓丹"},
		{Type: "item", Value: "sacrifice_stone", Amt: 1, Name: "献祭之石"},
		{Type: "stat", Value: "happiness", Amt: 30, Name: "飞跃的好心情"},
	}

	reward := rewardPool[rand.Intn(len(rewardPool))]

	// 2. 召唤 AI 讲述奇遇
	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)
	
	systemPrompt := "你是一位龙屿世界的吟游诗人。请根据用户的行为（喂食或陪玩）和获得的奖励，写一段50字以内的极具诗意和画面感的奇遇描述。严禁使用任何 Emoji 表情符号。格式：[奇遇内容] 获得：[奖励名称]"
	userPrompt := fmt.Sprintf("动作：%s，龙的名字：%s，品质：%s，获得的奖励：%s", actionType, dragon.Name, dragon.Rarity, reward.Name)
	
	story, _ := client.GetChatCompletion("gpt-4o-mini", userPrompt, systemPrompt)
	if story == "" {
		story = fmt.Sprintf("龙宝宝在%s时显得格外兴奋，似乎触发了某种远古共鸣！获得：%s", actionType, reward.Name)
	}

	// 3. 发放奖励
	if reward.Type == "stat" {
		if reward.Value == "exp" { dragon.Exp += reward.Amt }
		if reward.Value == "happiness" { dragon.Happiness += reward.Amt }
		global.DB.Save(dragon)
	} else if reward.Type == "item" {
		var item model.UserItem
		if err := global.DB.Where("user_id = ? AND type = ?", userID, reward.Value).First(&item).Error; err != nil {
			item = model.UserItem{UserID: userID, Type: reward.Value, Count: reward.Amt}
			global.DB.Create(&item)
		} else {
			item.Count += reward.Amt
			global.DB.Save(&item)
		}
	}

	return story, nil
}

// Feed 喂食 (消耗 UserItem food)
// Evolve 进化
func (s *DragonService) Evolve(userID uint, userToken string) (string, error) {
	dragon, err := s.GetDragon(userID)
	if err != nil { return "", err }
	if dragon.Stage >= 4 { return "", fmt.Errorf("已是真龙之躯，无可再进") }

	nextExp := (dragon.Stage + 1) * 200
	if dragon.Exp < nextExp {
		return "", fmt.Errorf("成长值不足，尚需修行 (当前: %d/%d)", dragon.Exp, nextExp)
	}

	stages := []string{"龙蛋", "幼龙", "青年龙", "壮年龙", "真龙"}
	oldStageName := stages[dragon.Stage]
	
	// 晋升阶段
	dragon.Stage++
	dragon.Exp = 0 
	dragon.MaxHunger += 50
	dragon.MaxHappiness += 50
	dragon.Hunger = dragon.MaxHunger
	dragon.Happiness = dragon.MaxHappiness

	newStageName := stages[dragon.Stage]

	// 自动进化 BasePrompt
	evolvedPrompt := s.triggerPromptEvolution(dragon.BasePrompt, oldStageName, newStageName)
	if evolvedPrompt != "" {
		dragon.BasePrompt = evolvedPrompt
	}

	if err := global.DB.Save(dragon).Error; err != nil {
		return "", err
	}
	fmt.Printf("[DB Update] Dragon %d (User %d) evolved to stage %d. New BasePrompt: %s\n", dragon.ID, userID, dragon.Stage, dragon.BasePrompt)

	// 自动触发新阶真身显像 (不传递参考图，让 AI 自由发挥)
	go s.GenerateImage(userID, userToken, "")

	return fmt.Sprintf("突破成功！你的龙嗣已进化为【%s】，其基因图谱已自适应演变。正在为你重塑新阶真身...", newStageName), nil
}

// triggerPromptEvolution 调用 AI 进化提示词
func (s *DragonService) triggerPromptEvolution(oldPrompt, oldStage, newStage string) string {
	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)
	
	systemPrompt := `You are a dragon genetic specialist. Rewrite the dragon's appearance description to reflect its evolution.
STAGES & TRANSITIONS:
- Hatchling (幼龙): Tiny, cute, baby dragon, breaking out of a shell, curious eyes, slightly clumsy.
- Young Dragon (青年龙): Slender, agile, and athletic. An adolescent dragon, sleek and fast. Smaller horns and wings. NOT bulky.
- Adult Dragon (壮年龙): Massive, heavy, and extremely muscular. Large wingspan, imposing presence, thick scales and large horns.
- True Dragon (真龙): A divine, celestial god-like entity. Radiating infinite energy, majestic and awe-inspiring scale.

Requirements:
1. KEEP the dragon's original color scheme and elemental affinity.
2. EMPHASIZE EXTREME SCALE: 
   - Hatchlings should be tiny enough to fit in a palm.
   - Young dragons should be the size of a large dog or horse.
   - Adult dragons should be massive, capable of crushing buildings or towering over trees.
   - True dragons should be of cosmic or mountain-like scale.
3. ABSOLUTELY FORBIDDEN: Do not mention 'egg', 'shell', or 'hatch' for Young, Adult, or True stages.
4. Output ONLY the new description in English, under 100 words. No introductory text.`
	userPrompt := fmt.Sprintf("Current Stage: %s, Next Stage: %s. Current Description: %s", oldStage, newStage, oldPrompt)
	
	newPrompt, err := client.GetChatCompletion("gpt-4o-mini", userPrompt, systemPrompt)
	if err != nil || newPrompt == "" {
		fmt.Printf("[Evolution Error] AI failed to respond: %v\n", err)
		// Fallback: ensure no "egg" is carried over
		return fmt.Sprintf("A powerful and majestic %s, radiating elemental energy with shimmering scales and a regal presence.", newStage)
	}
	fmt.Printf("[Evolution] Old: %s -> New: %s\n", oldPrompt, newPrompt)
	return newPrompt
}

func (s *DragonService) Feed(userID uint) (string, error) {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return "", errors.New("你还没有领养龙嗣")
	}

	if dragon.Hunger >= dragon.MaxHunger {
		return "", fmt.Errorf("它已经吃不下了 (上限: %d)", dragon.MaxHunger)
	}

	// 检查是否有龙粮
	var item model.UserItem
	if err := global.DB.Where("user_id = ? AND type = ?", userID, "food").First(&item).Error; err != nil || item.Count <= 0 {
		return "", errors.New("龙粮不足，请完成每日修行获取")
	}

	// 消耗龙粮
	item.Count--
	global.DB.Save(&item)

	dragon.Hunger += 20
	if dragon.Hunger > 100 {
		dragon.Hunger = 100
	}

	// 动态成长收益
	expGain := 10
	if dragon.Rarity == "rare" { expGain = 20 }
	if dragon.Rarity == "epic" { expGain = 40 }
	dragon.Exp += expGain

	now := time.Now()
	dragon.LastFedAt = &now

	if err := global.DB.Save(dragon).Error; err != nil {
		return "", err
	}

	// 更新任务进度
	s.UpdateTaskProgress(userID, "feed", 1)

	// 30% 概率触发随机事件
	eventMsg := "无事发生"
	if rand.Float32() < 0.3 {
		eventMsg, _ = s.TriggerRandomEvent(userID, "feed")
	}

	return eventMsg, nil
}

// Play 陪玩 (固定时间间隔 10 分钟)
func (s *DragonService) Play(userID uint) (string, error) {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return "", errors.New("你还没有领养龙嗣")
	}

	if dragon.Happiness >= dragon.MaxHappiness {
		return "", fmt.Errorf("它已经玩得很开心了 (上限: %d)", dragon.MaxHappiness)
	}

	// 检查时间间隔
	if dragon.LastPlayedAt != nil {
		if time.Since(*dragon.LastPlayedAt) < 10*time.Minute {
			wait := 10 - int(time.Since(*dragon.LastPlayedAt).Minutes())
			return "", fmt.Errorf("龙宝宝玩累了，请 %d 分钟后再来", wait)
		}
	}

	dragon.Happiness += 15
	if dragon.Happiness > 100 {
		dragon.Happiness = 100
	}

	// 动态成长收益
	expGain := 10
	if dragon.Rarity == "rare" { expGain = 20 }
	if dragon.Rarity == "epic" { expGain = 40 }
	dragon.Exp += expGain

	now := time.Now()
	dragon.LastPlayedAt = &now

	if err := global.DB.Save(dragon).Error; err != nil {
		return "", err
	}

	// 更新任务进度
	s.UpdateTaskProgress(userID, "play", 1)

	// 30% 概率触发随机事件
	eventMsg := "无事发生"
	if rand.Float32() < 0.3 {
		eventMsg, _ = s.TriggerRandomEvent(userID, "play")
	}

	return eventMsg, nil
}

// Rename 改名
func (s *DragonService) Rename(userID uint, name string) error {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return err
	}
	dragon.Name = name
	return global.DB.Save(dragon).Error
}

// ShareToChat 将龙的照片分享到聊天广场 (每日限1次)
func (s *DragonService) ShareToChat(userID uint) error {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return errors.New("你还没有领养龙嗣")
	}

	if dragon.ImageURL == "" || dragon.ImageURL == "[GENERATING]" {
		return errors.New("你的龙宝宝还没有幻化真身，快去显像吧")
	}

	// 校验每日分享次数
	today := time.Now().Format("2006-01-02")
	var task model.UserTask
	if err := global.DB.Where("user_id = ? AND task_type = ? AND date = ?", userID, "share", today).First(&task).Error; err == nil {
		if task.Progress >= 1 {
			return errors.New("今日已在广场展示过英姿，请明日再来")
		}
	}

	// 构造展示消息
	content := fmt.Sprintf("[真身显现] 游侠展示了他的龙宝宝 **%s**！\n\n![](%s)", dragon.Name, dragon.ImageURL)
	
	msg := &model.Message{
		Content: content,
		UserID:  &userID,
	}
	msg.CreatedAt = time.Now() // 显式设置时间，确保排序正确且广播有时间

	if err := global.DB.Create(msg).Error; err != nil {
		return err
	}

	// 广播前确保关联数据完整
	global.DB.Preload("User").First(msg, msg.ID)
	logic.GlobalHub.BroadcastMessage(msg)

	// 更新每日分享任务
	s.UpdateTaskProgress(userID, "share", 1)
	return nil
}

// UpdateTaskProgress 更新任务进度
func (s *DragonService) UpdateTaskProgress(userID uint, taskType string, amount int) {
	today := time.Now().Format("2006-01-02")
	var task model.UserTask
	
	if err := global.DB.Where("user_id = ? AND task_type = ? AND date = ?", userID, taskType, today).First(&task).Error; err != nil {
		// 创建新任务记录
		task = model.UserTask{
			UserID:      userID,
			TaskType:    taskType,
			Progress:    amount,
			MaxProgress: 1, 
			Date:        today,
		}
		global.DB.Create(&task)
	} else {
		if task.Progress < task.MaxProgress {
			task.Progress += amount
			if task.Progress > task.MaxProgress {
				task.Progress = task.MaxProgress
			}
			global.DB.Save(&task)
		}
	}
}

// GetDailyTasks 获取今日任务 (根据稀有度动态生成)
func (s *DragonService) GetDailyTasks(userID uint) []model.UserTask {
	dragon, _ := s.GetDragon(userID)
	rarity := "common"
	if dragon != nil {
		rarity = dragon.Rarity
	}

	today := time.Now().Format("2006-01-02")
	
	// 任务配置: {基础次数, 基础龙粮奖励, 基础经验奖励}
	configs := map[string][]int{
		"sign_in":  {1, 5, 10},   
		"chat":     {5, 5, 15},   
		"generate": {1, 10, 30},   
		"share":    {1, 10, 20},   
		"feed":     {3, 5, 10},
		"play":     {2, 5, 15},
		"fortune":  {1, 5, 10},
	}

	// 难度倍率
	diffMult := 1.0 
	if rarity == "rare" { 
		diffMult = 2.0
	}
	if rarity == "epic" { 
		diffMult = 3.5
	}

	var tasks []model.UserTask
	for tt, cfg := range configs {
		var task model.UserTask
		maxProgress := int(float64(cfg[0]) * diffMult)
		if maxProgress < 1 { maxProgress = 1 }

		if err := global.DB.Where("user_id = ? AND task_type = ? AND date = ?", userID, tt, today).First(&task).Error; err != nil {
			task = model.UserTask{
				UserID:      userID,
				TaskType:    tt,
				Progress:    0,
				MaxProgress: maxProgress,
				Date:        today,
			}
			global.DB.Create(&task)
		} else {
			task.MaxProgress = maxProgress
			task.TaskType = tt 
			global.DB.Save(&task)
		}
		tasks = append(tasks, task)
	}
	return tasks
}

// ClaimTaskReward 领取任务奖励
func (s *DragonService) ClaimTaskReward(userID uint, taskID uint) (string, error) {
	var task model.UserTask
	if err := global.DB.Where("id = ? AND user_id = ?", taskID, userID).First(&task).Error; err != nil {
		return "", errors.New("修行任务不存在")
	}

	if task.Progress < task.MaxProgress {
		return "", errors.New("修行尚未圆满，继续努力吧")
	}

	if task.IsClaimed {
		return "", errors.New("此项天恩奖励已领受")
	}

	dragon, _ := s.GetDragon(userID)
	rarity := "common"
	if dragon != nil { rarity = dragon.Rarity }

	rewardMult := 1.0
	if rarity == "rare" { rewardMult = 2.5 }
	if rarity == "epic" { rewardMult = 5.0 }

	rewards := map[string][]int{
		"sign_in":  {5, 10},  
		"chat":     {5, 15},
		"generate": {10, 30},
		"share":    {10, 20},
		"feed":     {5, 10},
		"play":     {5, 15},
		"fortune":  {5, 10},
	}

	cfg := rewards[task.TaskType]
	foodCount := int(float64(cfg[0]) * rewardMult)
	expGained := int(float64(cfg[1]) * rewardMult)

	// 发放奖励
	if foodCount > 0 {
		var item model.UserItem
		if err := global.DB.Where("user_id = ? AND type = ?", userID, "food").First(&item).Error; err != nil {
			item = model.UserItem{UserID: userID, Type: "food", Count: foodCount}
			global.DB.Create(&item)
		} else {
			item.Count += foodCount
			global.DB.Save(&item)
		}
	}

	if expGained > 0 && dragon != nil {
		dragon.Exp += expGained
		global.DB.Save(dragon)
	}

	task.IsClaimed = true
	global.DB.Save(&task)

	return fmt.Sprintf("领取成功！获得龙粮x%d, 经验x%d", foodCount, expGained), nil
}

// GenerateImage 提交显像任务
func (s *DragonService) GenerateImage(userID uint, userToken string, refImageURL string) error {
	dragon, err := s.GetDragon(userID)
	if err != nil {
		return err
	}

	todayStart := time.Now().Truncate(24 * time.Hour)
	var gCount int64
	global.DB.Model(&model.MagicRecord{}).Where("created_at >= ?", todayStart).Count(&gCount)
	if gCount >= 20 {
		return errors.New("今日龙主显像灵力已耗尽（20/20），请明日再试")
	}

	record := &model.MagicRecord{
		UserID: userID,
		Prompt: "Dragon Evolution Image",
	}
	global.DB.Create(record)

	stages := []string{"mystical egg", "hatchling dragon", "young dragon", "adult dragon", "divine true dragon"}
	sizeKeywords := []string{
		"tiny size, minuscule like a small toy", 
		"hand-sized baby, cute small proportions", 
		"horse-sized adolescent dragon, sleek medium build", 
		"colossal mountain-sized dragon, towering over clouds", 
		"infinite cosmic scale, god-like celestial entity",
	}
	
	currentStage := stages[0]
	currentSize := sizeKeywords[0]
	if dragon.Stage >= 0 && dragon.Stage < len(stages) {
		currentStage = stages[dragon.Stage]
		currentSize = sizeKeywords[dragon.Stage]
	}
	
	prompt := fmt.Sprintf("%s, %s, %s stage dragon, %s, extreme scale, comparison to environment, cinematic lighting, high detail, fantasy masterpiece, 8k", dragon.Rarity, currentSize, currentStage, dragon.BasePrompt)

	// 设置为生成中，触发前端动画
	global.DB.Model(&model.Dragon{}).Where("id = ?", dragon.ID).Update("image_url", "[GENERATING]")

	var refImages []string
	// 只有在手动触发且不是进化的初始显像时（即 prompt 为空或非进化阶段）才考虑参考图？
	// 这里根据用户需求：进化时不弄参考图了。
	// 如果是手动显像（GenerateImage 被 handler 调用且 refImageURL 为空），则不带参考图。
	if refImageURL != "" && !strings.HasPrefix(refImageURL, "[") {
		refImages = []string{refImageURL}
	}

	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)
	taskID, err := client.CreateImage(prompt, "1:1", "1k", refImages)
	if err != nil {
		return fmt.Errorf("显像任务提交失败: %v", err)
	}

	go s.PollDragonImage(taskID, dragon.ID, record.ID, userToken)
	s.UpdateTaskProgress(userID, "generate", 1)

	return nil
}

func (s *DragonService) PollDragonImage(taskID string, dragonID uint, recordID uint, userToken string) {
	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)

	for i := 0; i < 60; i++ {
		time.Sleep(10 * time.Second)
		res, err := client.GetTaskStatus(taskID)
		if err != nil {
			continue
		}

		if res.Data.Status == "completed" && len(res.Data.Result.Images) > 0 {
			remoteURL := res.Data.Result.Images[0].URL[0]
			cloudURL, err := s.uploadToCloud(remoteURL, userToken)
			if err != nil {
				cloudURL = remoteURL
			}

			global.DB.Model(&model.Dragon{}).Where("id = ?", dragonID).Update("image_url", cloudURL)
			return
		}
		if res.Data.Status == "failed" {
			global.DB.Model(&model.Dragon{}).Where("id = ?", dragonID).Update("image_url", "") 
			global.DB.Unscoped().Delete(&model.MagicRecord{}, recordID) 
			return
		}
	}
	global.DB.Model(&model.Dragon{}).Where("id = ?", dragonID).Update("image_url", "") 
	global.DB.Unscoped().Delete(&model.MagicRecord{}, recordID)
}

func (s *DragonService) uploadToCloud(remoteURL string, userToken string) (string, error) {
	resp, err := http.Get(remoteURL)
	if err != nil { return "", err }
	defer resp.Body.Close()
	data, _ := ioutil.ReadAll(resp.Body)

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, _ := writer.CreateFormFile("file", fmt.Sprintf("dragon_%d.jpg", time.Now().UnixNano()))
	io.Copy(part, bytes.NewReader(data))
	writer.Close()

	req, _ := http.NewRequest("POST", "http://xiaolongya.cn:8888/dragon/upload", body)
	req.Header.Set("Content-Type", writer.FormDataContentType())
	
	if !strings.HasPrefix(userToken, "Bearer ") {
		userToken = "Bearer " + userToken
	}
	req.Header.Set("Authorization", userToken)

	client := &http.Client{}
	resp2, err := client.Do(req)
	if err != nil { return "", err }
	defer resp2.Body.Close()

	var result struct {
		Code int `json:"code"`
		Data struct { URL string `json:"url"` } `json:"data"`
	}
	json.NewDecoder(resp2.Body).Decode(&result)
	return result.Data.URL, nil
}

// GetDragonChatHistory 获取龙的私聊记录
func (s *DragonService) GetDragonChatHistory(userID uint) ([]model.DragonMessage, error) {
	var dragon model.Dragon
	if err := global.DB.Where("user_id = ? AND is_gone = false", userID).First(&dragon).Error; err != nil {
		return nil, err
	}
	var msgs []model.DragonMessage
	err := global.DB.Where("dragon_id = ?", dragon.ID).Order("created_at asc").Find(&msgs).Error
	return msgs, err
}

// ChatWithDragon 与龙进行私聊
func (s *DragonService) ChatWithDragon(userID uint, content string) (string, error) {
	var dragon model.Dragon
	if err := global.DB.Where("user_id = ? AND is_gone = false", userID).First(&dragon).Error; err != nil {
		return "", errors.New("你还没有契约龙嗣")
	}

	// 1. 记录用户消息
	userMsg := model.DragonMessage{
		DragonID: dragon.ID,
		UserID:   userID,
		Role:     "user",
		Content:  content,
	}
	global.DB.Create(&userMsg)

	// 2. 获取最近上下文
	var history []model.DragonMessage
	global.DB.Where("dragon_id = ?", dragon.ID).Order("created_at desc").Limit(20).Find(&history)
	
	// 反转顺序为正序
	for i, j := 0, len(history)-1; i < j; i, j = i+1, j-1 {
		history[i], history[j] = history[j], history[i]
	}

	// 3. 构造 AI 指令
	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)
	
	systemPrompt := fmt.Sprintf(`You are a dragon named "%s". 
Stage: %d, Rarity: %s.
Your Memory: %s
Your Soul/Personality: %s
Current Appearance: %s

Guidelines:
1. Speak in a way that matches your stage (e.g., baby is cute/clumsy, adult is majestic).
2. Remember your past interactions from your Memory.
3. Be loyal to your master (the user).
4. Do NOT use any emojis.
5. Keep responses concise and mystical.`, dragon.Name, dragon.Stage, dragon.Rarity, dragon.Memory, dragon.Soul, dragon.BasePrompt)

	var chatMsgs []apimart.ChatMessage
	chatMsgs = append(chatMsgs, apimart.ChatMessage{Role: "system", Content: systemPrompt})
	for _, m := range history {
		role := "user"
		if m.Role == "dragon" {
			role = "assistant"
		}
		chatMsgs = append(chatMsgs, apimart.ChatMessage{Role: role, Content: m.Content})
	}

	reply, err := client.GetChatCompletionWithHistory("gpt-4o-mini", chatMsgs)
	if err != nil {
		return "", err
	}

	// 4. 记录龙的消息
	dragonReply := model.DragonMessage{
		DragonID: dragon.ID,
		UserID:   userID,
		Role:     "dragon",
		Content:  reply,
	}
	global.DB.Create(&dragonReply)

	// 5. 触发记忆与灵魂演变 (达到 20 条时)
	var count int64
	global.DB.Model(&model.DragonMessage{}).Where("dragon_id = ?", dragon.ID).Count(&count)
	if count >= 20 {
		go s.evolveDragonSoul(&dragon)
	}

	return reply, nil
}

// evolveDragonSoul 总结记忆并重塑灵魂
func (s *DragonService) evolveDragonSoul(dragon *model.Dragon) {
	fmt.Printf("[Soul Evolution] Dragon %s is evolving its soul...\n", dragon.Name)
	
	var msgs []model.DragonMessage
	global.DB.Where("dragon_id = ?", dragon.ID).Order("created_at asc").Find(&msgs)

	apiToken := global.CONFIG.GetString("APIMART_TOKEN")
	client := apimart.NewClient(apiToken)

	historyStr := ""
	for _, m := range msgs {
		historyStr += fmt.Sprintf("%s: %s\n", m.Role, m.Content)
	}

	systemPrompt := `You are a soul architect for dragons. Analyze the conversation history and the current state.
Update the dragon's Memory and Soul.
- Memory: A concise summary of important events and interactions (under 100 words).
- Soul: A description of its personality, temperament, and current emotional state (under 50 words).

Output ONLY in JSON format: {"memory": "...", "soul": "..."}`

	userPrompt := fmt.Sprintf("Current Memory: %s\nCurrent Soul: %s\n\nNew Conversations:\n%s", dragon.Memory, dragon.Soul, historyStr)
	
	resp, err := client.GetChatCompletion("gpt-4o-mini", userPrompt, systemPrompt)
	if err != nil {
		fmt.Printf("[Soul Evolution] Error: %v\n", err)
		return
	}

	var result struct {
		Memory string `json:"memory"`
		Soul   string `json:"soul"`
	}
	if err := json.Unmarshal([]byte(resp), &result); err != nil {
		// 尝试修复非 JSON 返回
		fmt.Printf("[Soul Evolution] JSON Parse Error: %v\n", err)
		return
	}

	// 更新龙的数据
	dragon.Memory = result.Memory
	dragon.Soul = result.Soul
	global.DB.Save(dragon)

	// 减少上下文：保留最近 10 条，删除旧消息
	var last10 []model.DragonMessage
	global.DB.Where("dragon_id = ?", dragon.ID).Order("created_at desc").Limit(10).Find(&last10)
	
	if len(last10) > 0 {
		oldestID := last10[len(last10)-1].ID
		global.DB.Where("dragon_id = ? AND id < ?", dragon.ID, oldestID).Unscoped().Delete(&model.DragonMessage{})
	}

	fmt.Printf("[Soul Evolution] Dragon %s soul evolved. New Soul: %s\n", dragon.Name, dragon.Soul)
}
